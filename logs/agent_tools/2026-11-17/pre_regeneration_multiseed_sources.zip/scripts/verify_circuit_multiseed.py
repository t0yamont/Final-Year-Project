"""Independent arithmetic and provenance audit of a completed multi-seed study."""
import argparse,gzip,hashlib,json,statistics
from pathlib import Path


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    manifest=json.loads((args.input/'manifest.json').read_text());count=0
    for group in ['inputs','sources','outputs']:
        for name,digest in manifest[group].items():
            if sha(name)!=digest:raise ValueError('hash mismatch: '+name)
            count+=1
    summary=json.loads((args.input/'metrics.json').read_text());cases=[]
    contract=json.loads((args.input/'contract.json').read_text());protocol=contract['protocol']
    baseline=Path(protocol['baselines'])
    for seed in protocol['training_seeds']:
        folder=args.input/f'seed-{seed}';sc=json.loads((folder/'contract.json').read_text());config=sc['config']
        reference=json.loads(Path(config['reference_config']).read_text());v=reference['vehicle'];initial=config['initial_speed_mps']
        zero={}
        for name,cells in [('training',sc['selected_cells']),('fine',config['fine_cells_per_block'])]:
            with gzip.open(baseline/f'blocks-{config["action_blocks"]}_cells-{cells}_zero.json.gz','rt') as f:zero[name]=json.load(f)['duration_s']
        for p in sorted(folder.glob('*.json.gz')):
            with gzip.open(p,'rt') as f:r=json.load(f)
            trace=r['trace'];end=trace[-1]['state']
            kinetic=.5*v['mass_kg']*(end['speed_m_per_s']**2-initial**2)
            net_work=sum(t['base_work_j']+t['electrical_work_j']-t['drag_work_j']-t['friction_braking_work_j'] for t in trace)
            residual=kinetic-net_work
            if abs(residual)>1:raise ValueError('global energy failed: '+str(p))
            electric=sum(t['electrical_work_j'] for t in trace)
            if abs(electric-v['discharge_efficiency']*(reference['initial_energy_j']-end['energy_j']))>.01:raise ValueError('battery/work identity failed')
            if abs(sum(t['duration_s'] for t in trace)-r['duration_s'])>1e-8:raise ValueError('duration mismatch')
            grid='fine' if p.name.endswith('_fine.json.gz') else 'training'
            if abs(r['reward_sum']-(zero[grid]-r['duration_s']))>1e-8:raise ValueError('reward identity mismatch')
            if abs(end['speed_m_per_s']-initial)>1e-5 or end['energy_j']<reference['reserve_j']-1e-5:raise ValueError('terminal constraint failed')
            if len(trace)!=config['action_blocks']:raise ValueError('decision-count mismatch')
            if any(t['max_node_cap_excess_mps']>1e-5 for t in trace):raise ValueError('speed constraint failed')
            cases.append(dict(file=str(p),global_energy_residual_j=residual,duration_s=r['duration_s']))
        metrics=json.loads((folder/'metrics.json').read_text())
        if metrics['actual_steps']!=protocol['steps_per_seed']:raise ValueError('incomplete training budget')
        if [c['step'] for c in metrics['checkpoints']]!=protocol['checkpoint_steps']:raise ValueError('missing checkpoint')
        if not all(c['gpu_training']['passed'] and c['gpu_training']['policy_device']=='cuda:0' for c in metrics['checkpoints'] if c['step']):raise ValueError('CUDA proof missing')
        if not metrics['checkpoint_reload_exact']:raise ValueError('reload check failed')
        for r in [metrics['final_deterministic'],*metrics['final_stochastic']]:
            discrepancy=abs((zero['training']-r['training_time_s'])-(zero['fine']-r['fine_time_s']))
            if abs(discrepancy-r['gain_discrepancy_s'])>1e-10:raise ValueError('gain discrepancy arithmetic')
    if summary['all_seeds_completed_and_passed']:
        data=[s['final_deterministic']['fine_time_s'] for s in summary['seeds']]
        if abs(statistics.mean(data)-summary['deterministic_lap_time_s']['mean'])>1e-10:raise ValueError('seed mean arithmetic')
        if abs(statistics.stdev(data)-summary['deterministic_lap_time_s']['sample_sd'])>1e-10:raise ValueError('seed SD arithmetic')
        nested=[statistics.mean(r['fine_time_s'] for r in s['final_stochastic']) for s in summary['seeds']]
        if abs(statistics.mean(nested)-summary['stochastic_seed_mean_lap_time_s']['mean'])>1e-10:raise ValueError('nested seed mean arithmetic')
    record=dict(hash_checks=count,replays_checked=len(cases),max_absolute_energy_residual_j=max(abs(c['global_energy_residual_j']) for c in cases),
                all_seeds_passed=summary['all_seeds_completed_and_passed'],cases=cases,script_sha256=sha(__file__))
    args.output.write_bytes((json.dumps(record,indent=2)+'\n').encode())
    print(json.dumps({k:v for k,v in record.items() if k!='cases'}))


if __name__=='__main__':main()
