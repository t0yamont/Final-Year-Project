"""Fixed-budget GPU multi-seed study with isolated, paired policy evaluation."""
import argparse,gzip,json,os,platform,subprocess,sys,time,traceback
from pathlib import Path
import numpy as np
import torch
import stable_baselines3
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.logger import configure
from f1energy.experiment import isolated_rng,describe,gain_discrepancy
from f1energy.training_device import require_cuda,verify_cuda_training
from f1energy.circuit_training_gate import validate_control_gate
from f1energy.circuit_control import rollout
from benchmark_circuit_control import load_setup,make_env,sha,save,gzsave,sources


def study_sources():
    result=sources()
    for name in [__file__,'scripts/benchmark_circuit_control.py','src/f1energy/experiment.py',
                 'src/f1energy/training_device.py','src/f1energy/circuit_training_gate.py']:
        result[str(Path(name))]=sha(name)
    return result


def worker(args,protocol):
    if args.seed not in protocol['training_seeds']:raise ValueError('seed not predeclared')
    root=Path(__file__).resolve().parents[1];gpu=require_cuda();torch.set_num_threads(1)
    config,gate=validate_control_gate(protocol['baselines'],root)
    args.output.mkdir(parents=True,exist_ok=False)
    before=study_sources();inputs={str(args.protocol):sha(args.protocol),str(Path(protocol['baselines'])/'manifest.json'):sha(Path(protocol['baselines'])/'manifest.json')}
    save(args.output/'contract.json',dict(protocol=protocol,config=config,seed=args.seed,gpu=gpu,sources=before,inputs=inputs,
        selected_cells=gate['selected_cells_per_block'],versions=dict(python=platform.python_version(),torch=torch.__version__,sb3=stable_baselines3.__version__,numpy=np.__version__)))
    ref,curve,vehicle=load_setup(config);cells=gate['selected_cells_per_block'];fine_cells=config['fine_cells_per_block']
    def environment(count):
        env=make_env(config,ref,curve,vehicle,count)
        with gzip.open(Path(protocol['baselines'])/f'blocks-{config["action_blocks"]}_cells-{count}_zero.json.gz','rt') as f:zero=json.load(f)
        env.reference_times=np.array([r['duration_s'] for r in zero['trace']]);return env,zero['duration_s']
    training,_=environment(cells);coarse,coarse_zero=environment(cells);fine,fine_zero=environment(fine_cells)
    hp=protocol['hyperparameters'];kwargs={k:v for k,v in hp.items() if k!='net_arch'}
    model=PPO('MlpPolicy',Monitor(training,str(args.output/'episodes')),seed=args.seed,device=gpu['device'],
              policy_kwargs=dict(net_arch=hp['net_arch']),verbose=0,**kwargs)
    model.set_logger(configure(str(args.output/'logs'),['csv']))
    checkpoints=[];training_seconds=0.;start=time.perf_counter()
    def pair(policy,deterministic,noise_seed,label):
        records=[]
        for grid,env in [('training',coarse),('fine',fine)]:
            with isolated_rng(noise_seed):
                record=rollout(env,lambda obs:policy.predict(obs,deterministic=deterministic)[0])
            gzsave(args.output/f'{label}_{grid}.json.gz',record);records.append(record)
        c,f=records
        return dict(training_time_s=c['duration_s'],fine_time_s=f['duration_s'],
            fine_gain_s=fine_zero-f['duration_s'],fine_final_energy_j=f['final_energy_j'],
            gain_discrepancy_s=gain_discrepancy(c['duration_s'],f['duration_s'],coarse_zero,fine_zero),
            feasible=bool(c['feasible'] and f['feasible']),noise_seed=noise_seed,
            fine_energy_residual_j=f['energy_residual_j'],fine_terminal_speed_error_mps=f['terminal_speed_error_mps'])
    for target in protocol['checkpoint_steps']:
        if target:
            before_train=time.perf_counter()
            model.learn(total_timesteps=target-model.num_timesteps,reset_num_timesteps=False)
            torch.cuda.synchronize();training_seconds+=time.perf_counter()-before_train
            device_check=verify_cuda_training(model)
        else:device_check=None
        if model.num_timesteps!=target:raise RuntimeError('unexpected training budget')
        model.save(args.output/f'checkpoint_{target}')
        record=pair(model,True,9001,f'checkpoint_{target}_deterministic')
        row=dict(step=target,gpu_training=device_check,**record);checkpoints.append(row)
        save(args.output/'progress.json',dict(seed=args.seed,completed_steps=target,checkpoints=checkpoints,training_seconds=training_seconds))
        print(json.dumps(dict(seed=args.seed,step=target,fine_time_s=record['fine_time_s'],feasible=record['feasible'])),flush=True)
    # Model construction/loading must not alter RNG state used by later checks.
    with isolated_rng(9001):loaded=PPO.load(args.output/f'checkpoint_{protocol["steps_per_seed"]}.zip',device=gpu['device'])
    reloaded=pair(loaded,True,9001,'reloaded_final_deterministic')
    if reloaded!={k:v for k,v in checkpoints[-1].items() if k not in ['step','gpu_training']}:
        raise RuntimeError('checkpoint reload changed replay')
    stochastic=[pair(loaded,False,s,f'final_stochastic_{s}') for s in protocol['stochastic_evaluation_seeds']]
    evaluated=[checkpoints[-1],*stochastic]
    passed=all(r['feasible'] and r['gain_discrepancy_s']<=config['gates']['gain_error_s'] for r in evaluated)
    summary=dict(seed=args.seed,actual_steps=model.num_timesteps,training_seconds=training_seconds,elapsed_seconds=time.perf_counter()-start,
        checkpoints=checkpoints,final_deterministic=checkpoints[-1],final_stochastic=stochastic,
        stochastic_within_seed=describe([r['fine_time_s'] for r in stochastic]),
        final_replay_gate_passed=bool(passed),checkpoint_reload_exact=True,
        limitation='Nominal assumed-model learning study; five stochastic rollouts are nested within one training seed')
    save(args.output/'metrics.json',summary)
    if any(sha(name)!=digest for name,digest in before.items()):raise RuntimeError('source changed during training')
    save(args.output/'manifest.json',dict(inputs=inputs,sources=before,outputs={str(p):sha(p) for p in args.output.rglob('*') if p.is_file()}))
    if not passed:raise SystemExit(2)


def coordinator(args,protocol):
    config,gate=validate_control_gate(protocol['baselines'],Path(__file__).resolve().parents[1]);gpu=require_cuda()
    args.output.mkdir(parents=True,exist_ok=False)
    before=study_sources();inputs={str(args.protocol):sha(args.protocol),str(Path(protocol['baselines'])/'manifest.json'):sha(Path(protocol['baselines'])/'manifest.json')}
    save(args.output/'contract.json',dict(protocol=protocol,gpu=gpu,inputs=inputs,sources=before,logical_cpu_count=os.cpu_count()))
    pending=list(protocol['training_seeds']);running={};finished={};handles=[]
    workers=min(protocol['parallel_workers'],max(1,(os.cpu_count() or 2)-1))
    try:
        while pending or running:
            while pending and len(running)<workers:
                seed=pending.pop(0);log=(args.output/f'seed-{seed}.log').open('w',encoding='utf-8');handles.append(log)
                cmd=[sys.executable,str(Path(__file__).resolve()),'--protocol',str(args.protocol),'--output',str(args.output/f'seed-{seed}'),'--seed',str(seed)]
                running[seed]=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            for seed,process in list(running.items()):
                if process.poll() is not None:finished[str(seed)]=process.returncode;del running[seed]
            save(args.output/'workers.json',dict(running={str(s):p.pid for s,p in running.items()},finished=finished,pending=pending))
            if running:time.sleep(2)
    finally:
        for p in running.values():
            if p.poll() is None:p.terminate();p.wait()
        for log in handles:log.close()
    summaries=[]
    for seed in protocol['training_seeds']:
        p=args.output/f'seed-{seed}'/'metrics.json'
        if p.exists():summaries.append(json.loads(p.read_text()))
    accepted=len(summaries)==len(protocol['training_seeds']) and all(code==0 for code in finished.values()) and all(s['final_replay_gate_passed'] for s in summaries)
    result=dict(all_seeds_completed_and_passed=bool(accepted),worker_exit_codes=finished,seeds=summaries,
                scope=protocol['study'],primary_endpoint=protocol['primary_endpoint'],parallel_workers_used=workers)
    if accepted:
        result['deterministic_lap_time_s']=describe([s['final_deterministic']['fine_time_s'] for s in summaries])
        result['deterministic_gain_s']=describe([s['final_deterministic']['fine_gain_s'] for s in summaries])
        result['stochastic_seed_mean_lap_time_s']=describe([s['stochastic_within_seed']['mean'] for s in summaries])
    fine_rows=[r for r in gate['results'] if r['blocks']==config['action_blocks'] and r['cells']==config['fine_cells_per_block']]
    result['fine_baselines_s']={r['policy']:r['duration_s'] for r in fine_rows}
    save(args.output/'metrics.json',result)
    if any(sha(p)!=h for p,h in before.items()):raise RuntimeError('source changed during study')
    save(args.output/'manifest.json',dict(inputs=inputs,sources=before,outputs={str(p):sha(p) for p in args.output.rglob('*') if p.is_file()}))
    print(json.dumps({k:v for k,v in result.items() if k!='seeds'},indent=2),flush=True)
    if not accepted:raise SystemExit(2)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--protocol',type=Path,default=Path('configs/circuit_multiseed_protocol.json'));parser.add_argument('--seed',type=int)
    args=parser.parse_args();protocol=json.loads(args.protocol.read_text())
    steps=protocol['steps_per_seed'];points=protocol['checkpoint_steps']
    if steps!=16384 or points!=[0,4096,8192,12288,16384] or len(set(protocol['training_seeds']))!=3:raise ValueError('bounded study requires three unique seeds and fixed16384-step schedule')
    try:
        if args.seed is None:coordinator(args,protocol)
        else:worker(args,protocol)
    except Exception:
        if args.output.exists():save(args.output/'failure.json',dict(error=traceback.format_exc()))
        raise


if __name__=='__main__':main()
